package com.example.workerproblem;

import androidx.appcompat.app.AppCompatActivity;

public class ShowSnapsActivity extends AppCompatActivity {
}
